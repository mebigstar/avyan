
let date = new Date();
date = date.toLocaleDateString();

export const blogs = [
    {
        id: '00000000000.1',
        image: '/blog_1.jpg',
        status:'Travel',
        date: date,
        title: 'Train or Bus journey? Why on suits?',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
    {
        id: '00000000000.2',
        image: '/blog_2.jpg',
        status:'Development',
        date: date,
        title: 'best website to research for your next project',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
    {
        id: '00000000000.3',
        image: '/blog_3.jpg',
        status:'Development',
        date: date,
        title: 'how to be a dancer in 2025 with proper skills',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
    {
        id: '00000000000.4',
        image: '/blog_4.jpg',
        status:'Development',
        date: date,
        title: 'who is best singer on chart? know him?',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
    {
        id: '00000000000.5',
        image: '/blog_5.jpg',
        status:'Development',
        date: date,
        title: 'How to start export import business from home',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
    {
        id: '00000000000.6',
        image: '/blog_6.jpg',
        status:'travel',
        date: date,
        title: '8 rules of traveling in sea you need to know',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
    {
        id: '00000000000.7',
        image: '/blog_7.jpg',
        status:'travel',
        date: date,
        title: 'How to build strong portfolio and get a job in UI/UX',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
    {
        id: '00000000000.8',
        image: '/blog_7.jpg',
        status:'footboller',
        date: date,
        title: 'how to be a professional footballer in 2025',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
    {
        id: '00000000000.9',
        image: '/blog_6.jpg',
        status:'travel',
        date: date,
        title: '8 rules of traveling in sea you need to know',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga nisi autem voluptate voluptatum repellat accusamus soluta reprehenderit temporibus dolore cumque eos ut laborum, architecto ab ex ad quae magnam ea alias aliquid modi facere nostrum. Inventore numquam assumenda eaque beatae a saepe repudiandae id eum. Velit doloribus pariatur est quos!'
    },
]